// console.log('Welcome to TypScript');
// let username: string;
// let age: number;
// let taskCompleted: boolean;
// let hobbies: Array<string>;
// // let hobbies: string[];
// username = 'John';
// age = 25;
// taskCompleted = true;
// hobbies = ['Singing', 'Dancing', 'Watching TV'];
// let book: [number, string, boolean];
// book = [1, 'Learn JavaScript', true];
// enum color {
//     Red,
//     Blue,
//     Green,
//     Yellow
// }
// let c: string = color[2];
// let myvar: any = 'hello';
// let num: number = myvar;
// myvar = 'Hello';
// // myvar = 10;
// console.log(username);
// console.log(hobbies);
// console.log(book);
// console.log(c);
// console.log(myvar);
// console.log(num);
// function Show(): void {
//     return 'Hello';
// }
// const Show = (): string => {
//     return 'Hello';
//     // console.log('Hello');
// }
// function SayHello(username: string): string {
//     return `Hello ${username}`;
// }
// console.log(SayHello('Peter'));
// let person: object;
// person = {
//     fname: 'Peter',
//     lname: 'Parker'
// }
// console.log(person['fname']);
// interface Person {
//     fname: string,
//     lname: string,
//     age: number
// }
// let p1: Person = {
//     fname: 'Peter',
//     lname: 'Parker',
//     age: 25
// };
// let p2: Person = {
//     fname: 'James',
//     lname: 'Cameron',
//     age: 45
// };
// console.log(p1.fname);
// console.log(p2.fname);
var Person = /** @class */ (function () {
    function Person(fname, lname) {
        console.log('This is constructor');
        this.FirstName = fname;
        this.LastName = lname;
    }
    Person.prototype.Show = function () {
        console.log(this.FirstName, this.LastName);
    };
    return Person;
}());
var p1 = new Person('John', 'Smith');
// p1.Assign('John', 'Smith');
p1.Show();
